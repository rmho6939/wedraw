
export enum UserRole {
  GUEST = 'GUEST',
  FREE_USER = 'FREE_USER',
  PAID_USER = 'PAID_USER',
  ADMIN = 'ADMIN',
}

export enum SubscriptionTier {
  FREE = 'FREE',
  STARTER = 'STARTER',      // $198
  BUSINESS = 'BUSINESS',    // $398
  ENTERPRISE = 'ENTERPRISE' // $798
}

export const TIER_LIMITS = {
  [SubscriptionTier.FREE]: { activities: 0, rounds: 0, participants: 0 },
  [SubscriptionTier.STARTER]: { activities: 3, rounds: 10, participants: 500 },
  [SubscriptionTier.BUSINESS]: { activities: 10, rounds: 30, participants: 10000 },
  [SubscriptionTier.ENTERPRISE]: { activities: 20, rounds: 100, participants: 100000 },
};

export enum DrawMode {
  JUMP = 'JUMP',    // 名字跳跳
  GACHA = 'GACHA',  // 扭蛋機
}

export interface Participant {
  id: string;
  name: string;
  weight?: number; // default 1
  avatar?: string;
}

export interface Winner extends Participant {
  wonAt: string; // ISO Date
  prizeName: string;
}

export interface Round {
  id: string;
  name: string; // e.g., "三等獎"
  mode: DrawMode;
  prizeName: string;
  prizeImage?: string; // Base64 image string
  winnerCount: number;
  removeWinner: boolean; // 是否剔除中獎者
  winners: Winner[];
  isCompleted: boolean;
  riggedWinnerId?: string; // Enterprise feature: Pre-selected winner
}

export interface Activity {
  id: string;
  name: string; // e.g., "2025 公司年會"
  date: string;
  participants: Participant[];
  rounds: Round[];
  userId: string; // Owner
}

export interface User {
  id: string;
  email: string;
  password?: string; 
  role: UserRole;
  tier: SubscriptionTier;
  joinedAt: string;
  subscriptionEndDate?: string;
}

export interface PaymentRecord {
  id: string;
  userId: string;
  userEmail: string;
  amount: string;
  currency: string;
  planId: string;
  tier: SubscriptionTier;
  orderId: string;
  createdAt: string;
}

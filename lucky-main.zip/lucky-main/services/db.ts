import { db } from './firebase';
import { collection, doc, setDoc, getDocs, deleteDoc, query, where, updateDoc, onSnapshot, addDoc } from 'firebase/firestore';
import { User, Activity, PaymentRecord } from '../types';

const USERS_COLLECTION = 'luckyflow_users';
const ACTIVITIES_COLLECTION = 'luckyflow_activities';
const PAYMENTS_COLLECTION = 'luckyflow_payments';

export const dbService = {
  // --- USER MANAGEMENT ---

  saveUser: async (user: User) => {
    try {
      await setDoc(doc(db, USERS_COLLECTION, user.id), user, { merge: true });
    } catch (fbError: any) {
      console.error("🔥 Firestore Save User Error:", fbError.message);
    }
  },

  // Admin manual creation
  createUser: async (user: User) => {
    try {
      await setDoc(doc(db, USERS_COLLECTION, user.id), user);
    } catch (fbError: any) {
      console.error("🔥 Firestore Create User Error:", fbError.message);
      throw fbError;
    }
  },

  updateUser: async (userId: string, data: Partial<User>) => {
    try {
      await updateDoc(doc(db, USERS_COLLECTION, userId), data);
    } catch (fbError: any) {
      console.error("🔥 Firestore Update User Error:", fbError.message);
      throw fbError;
    }
  },

  // Real-time listener for the current user
  listenToUserProfile: (userId: string, callback: (user: User | null) => void) => {
    return onSnapshot(doc(db, USERS_COLLECTION, userId), (docSnap) => {
      if (docSnap.exists()) {
        callback(docSnap.data() as User);
      } else {
        callback(null);
      }
    }, (error) => {
      console.error("🔥 Firestore Listen Error:", error);
    });
  },

  getUsers: async (): Promise<User[]> => {
    try {
      const querySnapshot = await getDocs(collection(db, USERS_COLLECTION));
      const users: User[] = [];
      querySnapshot.forEach((doc) => {
        users.push(doc.data() as User);
      });
      return users;
    } catch (fbError: any) {
       console.error("🔥 Firestore Fetch Users Error:", fbError.message);
       return [];
    }
  },

  deleteUser: async (userId: string) => {
    try {
      await deleteDoc(doc(db, USERS_COLLECTION, userId));
    } catch (fbError: any) {
       console.error("🔥 Firestore Delete User Error:", fbError.message);
       throw fbError;
    }
  },

  // --- PAYMENTS ---

  recordPayment: async (record: PaymentRecord) => {
    try {
       await setDoc(doc(db, PAYMENTS_COLLECTION, record.id), record);
    } catch (fbError: any) {
      console.error("🔥 Payment Record Error:", fbError.message);
    }
  },

  getPayments: async (): Promise<PaymentRecord[]> => {
    try {
      const q = query(collection(db, PAYMENTS_COLLECTION));
      const querySnapshot = await getDocs(q);
      const payments: PaymentRecord[] = [];
      querySnapshot.forEach((doc) => {
        payments.push(doc.data() as PaymentRecord);
      });
      // Sort by newest first
      return payments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (fbError: any) {
      console.error("🔥 Payment Fetch Error:", fbError.message);
      return [];
    }
  },

  // --- ACTIVITY MANAGEMENT ---

  saveActivity: async (activity: Activity, userId: string) => {
    try {
      const activityData = { ...activity, userId }; 
      await setDoc(doc(db, ACTIVITIES_COLLECTION, activity.id), activityData);
    } catch (fbError: any) {
      console.error("🔥 Firestore Save Activity Error:", fbError.message);
      throw fbError;
    }
  },

  getUserActivities: async (userId: string): Promise<Activity[]> => {
    try {
      const q = query(collection(db, ACTIVITIES_COLLECTION), where("userId", "==", userId));
      const querySnapshot = await getDocs(q);
      const activities: Activity[] = [];
      querySnapshot.forEach((doc) => {
        activities.push(doc.data() as Activity);
      });
      return activities;
    } catch (fbError: any) {
      console.error("🔥 Firestore Get Activities Error:", fbError.message);
      return [];
    }
  },

  deleteActivity: async (activityId: string) => {
    try {
      await deleteDoc(doc(db, ACTIVITIES_COLLECTION, activityId));
    } catch (fbError: any) {
      console.error("🔥 Firestore Delete Activity Error:", fbError.message);
      throw fbError;
    }
  }
};

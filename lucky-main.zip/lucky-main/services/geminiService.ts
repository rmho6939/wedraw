import { GoogleGenAI } from "@google/genai";

// Use environment variable, fallback to empty string (will cause error if used without key)
const API_KEY = process.env.API_KEY || '';

let aiClient: GoogleGenAI | null = null;

const getClient = () => {
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey: API_KEY });
  }
  return aiClient;
};

export const generateHypeMessage = async (winnerName: string, prizeName: string, context: string = "公司年會"): Promise<string> => {
  if (!API_KEY) {
    console.warn("No API Key found for Gemini");
    return `恭喜 ${winnerName} 獲得 ${prizeName}！太幸運了！`;
  }

  try {
    const client = getClient();
    const prompt = `
      你是一個專業的活動主持人。
      請用繁體中文（香港口語風格），為這位得獎者生成一句簡短、幽默且充滿激情的祝賀詞。
      
      得獎者：${winnerName}
      獎品：${prizeName}
      場合：${context}
      
      限制：50字以內，不要用引號，直接輸出內容。
    `;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Gemini API Error:", error);
    return `恭喜 ${winnerName} 獲得 ${prizeName}！(AI 連線失敗但運氣爆棚！)`;
  }
};

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBVHmQGmj6x3Mpkf-Afin5ztJV1DPtleJ0",
  authDomain: "wedraw-c059b.firebaseapp.com",
  projectId: "wedraw-c059b",
  storageBucket: "wedraw-c059b.firebasestorage.app",
  messagingSenderId: "26954215866",
  appId: "1:26954215866:web:91c520f7922b1639066d83",
  measurementId: "G-5JM6EF7MXD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
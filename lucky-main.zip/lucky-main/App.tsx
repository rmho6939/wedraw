import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route, Link, useNavigate, useParams, Navigate, useLocation } from 'react-router-dom';
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, sendPasswordResetEmail } from "firebase/auth";
import { auth, googleProvider } from './services/firebase';
import { UserRole, SubscriptionTier, TIER_LIMITS, DrawMode, Activity, Round, Participant, Winner, User, PaymentRecord } from './types';
import { dbService } from './services/db';
import { generateHypeMessage } from './services/geminiService';
import * as XLSX from 'xlsx';
import { Helmet } from 'react-helmet-async';

// --- Constants & Config ---

const PAYPAL_CLIENT_ID = "Adc_QFLvb-c4Hw9zjWtkByTakvpcpWYwU4IGazqo0MC2qEivjFFvKIgsP4LZvdXwk26XZ5wcetBVjC4N"; 
const PLAN_IDS = {
  STARTER: "P-6US68136GF407792VNEQ3YIQ", // $198
  BUSINESS: "P-93B49438LH290032DNEQ3XGQ", // $398
  ENTERPRISE: "P-2YF8055399099794LNEQ3YRI" // $798
};

const ADMIN_EMAIL = "ho090827@gmail.com";

// --- Icons ---
type IconProps = { className?: string };
const Icons = {
  Gift: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>,
  Users: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  Play: ({ className = "w-12 h-12" }: IconProps) => <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>,
  Settings: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  X: ({ className = "w-6 h-6" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" /></svg>,
  Trash: ({ className = "w-4 h-4" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
  Plus: ({ className = "w-4 h-4" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4v16m8-8H4" /></svg>,
  Edit: ({ className = "w-4 h-4" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>,
  ChevronRight: ({ className = "w-6 h-6" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5l7 7-7 7" /></svg>,
  ChevronLeft: ({ className = "w-6 h-6" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 19l-7-7 7-7" /></svg>,
  Check: ({ className = "w-6 h-6" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>,
  Exit: ({ className = "w-6 h-6" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>,
  Image: ({ className = "w-4 h-4" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Shield: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
  Google: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" /><path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" /><path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z" /><path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" /></svg>,
  Lock: ({ className = "w-12 h-12" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>,
  CreditCard: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>,
  Logout: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>,
  BookOpen: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>,
  Upload: ({ className = "w-5 h-5" }: IconProps) => <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
};

// --- UI Components ---

const LoadingScreen: React.FC = () => (
  <div className="fixed inset-0 bg-white flex flex-col items-center justify-center z-[999]">
      <div className="w-12 h-12 border-4 border-black border-t-transparent rounded-full animate-spin mb-4"></div>
      <div className="text-gray-500 font-bold tracking-widest">LOADING</div>
  </div>
);

const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode, maxWidth?: string }> = ({ isOpen, onClose, title, children, maxWidth = "max-w-md" }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-[fade-in_0.2s_ease-out]">
      <div className={`bg-white rounded-xl shadow-2xl w-full ${maxWidth} overflow-hidden border border-gray-100 transform transition-all`}>
        <div className="flex justify-between items-center p-5 border-b border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 tracking-tight">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-900 transition"><Icons.X /></button>
        </div>
        <div className="p-6 max-h-[80vh] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

const ExitConfirmModal: React.FC<{ isOpen: boolean; onCancel: () => void; onConfirm: () => void }> = ({ isOpen, onCancel, onConfirm }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-[fade-in_0.2s_ease-out]">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center">
         <div className="mb-4 text-gray-500"><Icons.Exit className="w-12 h-12 mx-auto mb-2" /></div>
         <h3 className="text-xl font-bold text-gray-900 mb-2">確定要退出抽獎？</h3>
         <p className="text-gray-500 mb-6">當前的抽獎進度將會保存。</p>
         <div className="flex gap-3">
             <button onClick={onCancel} className="flex-1 py-3 rounded-xl border border-gray-200 font-bold text-gray-600 hover:bg-gray-50 transition">取消</button>
             <button onClick={onConfirm} className="flex-1 py-3 rounded-xl bg-red-600 font-bold text-white hover:bg-red-700 transition">退出</button>
         </div>
      </div>
    </div>
  );
};

// --- Wizards & Forms ---

const ActivityWizard: React.FC<{ isOpen: boolean; onClose: () => void; onComplete: (name: string) => void }> = ({ isOpen, onClose, onComplete }) => {
    const [step, setStep] = useState(1);
    const [name, setName] = useState('');

    if(!isOpen) return null;

    const next = () => setStep(step + 1);
    const back = () => setStep(step - 1);

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="建立新活動" maxWidth="max-w-lg">
            <div className="py-2">
                <div className="flex gap-2 mb-8">
                    {[1, 2, 3].map(i => (
                        <div key={i} className={`h-2 flex-1 rounded-full transition-all ${step >= i ? 'bg-black' : 'bg-gray-200'}`}></div>
                    ))}
                </div>
                
                {step === 1 && (
                    <div className="animate-fade-in">
                        <h4 className="text-xl font-bold mb-2">步驟 1: 活動名稱</h4>
                        <p className="text-gray-500 text-sm mb-6">請輸入這次抽獎活動的主題，例如「2025 公司年會」或「粉絲回饋活動」。</p>
                        <input className="w-full bg-gray-50 border border-gray-200 rounded-lg p-4 text-lg outline-none focus:border-black transition" placeholder="輸入活動名稱..." value={name} onChange={e => setName(e.target.value)} autoFocus />
                    </div>
                )}

                {step === 2 && (
                    <div className="animate-fade-in">
                        <h4 className="text-xl font-bold mb-2">步驟 2: 確認設定</h4>
                        <p className="text-gray-500 text-sm mb-6">活動建立後，您可以隨時在 Dashboard 新增抽獎輪次和匯入名單。</p>
                        <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                            <span className="text-xs font-bold text-gray-400 uppercase">活動名稱</span>
                            <div className="text-lg font-bold">{name}</div>
                            <div className="text-sm text-gray-500 mt-1">建立日期: {new Date().toLocaleDateString()}</div>
                        </div>
                    </div>
                )}

                {step === 3 && (
                    <div className="animate-fade-in text-center py-4">
                        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4"><Icons.Check className="w-8 h-8" /></div>
                        <h4 className="text-xl font-bold mb-2">準備就緒！</h4>
                        <p className="text-gray-500 text-sm">點擊下方按鈕完成建立，開始您的抽獎之旅。</p>
                    </div>
                )}

                <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
                    {step > 1 ? <button onClick={back} className="text-gray-500 font-bold px-4 hover:text-black">上一步</button> : <div></div>}
                    {step < 3 ? (
                        <button onClick={next} disabled={!name.trim()} className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed">下一步</button>
                    ) : (
                        <button onClick={() => onComplete(name)} className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">建立活動</button>
                    )}
                </div>
            </div>
        </Modal>
    );
};


// --- Draw Engines (Unchanged) ---
const JumpEngine: React.FC<{ participants: Participant[]; isRunning: boolean; targetWinners: Winner[] | null; onComplete: () => void; }> = ({ participants, isRunning, targetWinners, onComplete }) => {
  const [displayName, setDisplayName] = useState("READY");
  const [revealedNames, setRevealedNames] = useState<string[]>([]);
  const engineRef = useRef<any>(null);

  useEffect(() => {
    if (isRunning && targetWinners && targetWinners.length > 0) {
        setRevealedNames([]);
        let currentWinnerIndex = 0;
        let speed = 50;
        let steps = 0;
        const loop = () => {
            const randomIdx = Math.floor(Math.random() * participants.length);
            setDisplayName(participants[randomIdx].name);
            steps++;
            if (steps > 30) speed = speed * 1.1;

            if (steps >= 45) {
                const winner = targetWinners[currentWinnerIndex];
                setDisplayName(winner.name);
                setTimeout(() => {
                    setRevealedNames(prev => [...prev, winner.name]);
                    currentWinnerIndex++;
                    if (currentWinnerIndex < targetWinners.length) {
                        speed = 50; steps = 0;
                        engineRef.current = setTimeout(loop, 500); 
                    } else {
                        setTimeout(onComplete, 1000);
                    }
                }, 1000);
            } else {
                engineRef.current = setTimeout(loop, speed);
            }
        };
        loop();
    }
    return () => clearTimeout(engineRef.current);
  }, [isRunning, targetWinners]);

  return (
    <div className="flex flex-col items-center justify-center h-full w-full max-w-5xl mx-auto">
      <div className="relative z-10 text-center w-full mb-12">
         <div className={`text-[12vw] md:text-[8rem] font-black text-white leading-none tracking-tighter drop-shadow-2xl transition-all duration-100 ${isRunning ? 'scale-105' : 'scale-100'}`} style={{ textShadow: '0 10px 40px rgba(0,0,0,0.5)' }}>{displayName}</div>
      </div>
      {revealedNames.length > 0 && (
          <div className="flex flex-wrap justify-center gap-6 animate-slide-up">
              {revealedNames.map((name, i) => (
                  <div key={i} className="flex flex-col items-center animate-slide-up">
                      <span className="text-xs text-indigo-200 mb-1 font-bold uppercase tracking-widest">第 {i + 1} 位得獎者</span>
                      <div className="px-8 py-3 bg-white/20 backdrop-blur-md rounded-full text-white font-bold text-2xl border border-white/10 shadow-lg">{name}</div>
                  </div>
              ))}
          </div>
      )}
    </div>
  );
};

const GachaEngine: React.FC<{ isRunning: boolean; targetWinners: Winner[] | null; onComplete: () => void }> = ({ isRunning, targetWinners, onComplete }) => {
  const [phase, setPhase] = useState<'IDLE' | 'SHUFFLING' | 'DROPPING' | 'OPENING' | 'REVEAL'>('IDLE');
  useEffect(() => {
      if (isRunning) {
          setPhase('SHUFFLING');
          setTimeout(() => setPhase('DROPPING'), 3000);
          setTimeout(() => setPhase('OPENING'), 4200);
          setTimeout(() => { setPhase('REVEAL'); setTimeout(onComplete, 800); }, 5000);
      } else { setPhase('IDLE'); }
  }, [isRunning]);
  const balls = useRef(Array.from({ length: 15 }).map((_, i) => ({
    color: ['bg-red-500', 'bg-blue-600', 'bg-yellow-400', 'bg-green-500', 'bg-purple-600', 'bg-pink-500'][i % 6],
    left: `${10 + Math.random() * 80}%`,
    top: `${40 + Math.random() * 50}%`,
    size: `${40 + Math.random() * 30}px`,
    rotation: Math.random() * 360
  }))).current;

  return (
    <div className="flex items-center justify-center h-full relative perspective-1000">
      <div className={`relative w-[350px] h-[500px] md:w-[450px] md:h-[600px] flex flex-col items-center transition-transform duration-500`}>
        <div className="w-full h-[60%] relative overflow-hidden rounded-t-[200px] z-10 bg-gradient-to-br from-white/20 to-white/5 border-4 border-white/40 backdrop-blur-sm shadow-[0_0_50px_rgba(255,255,255,0.1)]">
             <div className="absolute top-10 right-10 w-20 h-32 bg-gradient-to-b from-white/40 to-transparent rounded-full transform rotate-[25deg]"></div>
             {balls.map((ball, i) => (
               <div key={i} className={`absolute rounded-full shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.3)] border border-white/20 ${ball.color} flex items-center justify-center`}
                 style={{ width: ball.size, height: ball.size, left: ball.left, top: phase === 'SHUFFLING' ? `${10 + Math.random() * 80}%` : ball.top, transform: `rotate(${ball.rotation}deg)`, animation: phase === 'SHUFFLING' ? `tumble ${0.3 + Math.random() * 0.5}s infinite linear alternate` : 'bounce-ball 2s infinite ease-in-out', transition: 'all 0.3s ease-out' }}>
                 <span className="text-white/40 font-bold text-xs">Lucky</span>
               </div>
             ))}
        </div>
        <div className="w-[110%] h-[40%] -mt-8 bg-gradient-to-b from-indigo-500 to-indigo-900 rounded-3xl border-t-8 border-white/20 flex flex-col items-center relative z-20 shadow-2xl">
             <div className="mt-6 text-white/80 font-black tracking-[0.5em] text-sm z-30">GACHA MACHINE</div>
             <div className="absolute top-1/3 flex items-center justify-center z-30">
                 <div className={`w-24 h-24 rounded-full bg-gray-200 shadow-[0_5px_15px_rgba(0,0,0,0.3),inset_0_-4px_4px_rgba(0,0,0,0.1)] border-4 border-gray-300 flex items-center justify-center transition-all duration-500 ${phase === 'SHUFFLING' || phase === 'DROPPING' ? 'animate-spin-handle' : ''}`}>
                     <div className="w-28 h-8 bg-gray-400 rounded-full shadow-lg flex items-center justify-between px-2"><div className="w-4 h-4 bg-gray-500 rounded-full shadow-inner"></div><div className="w-4 h-4 bg-gray-500 rounded-full shadow-inner"></div></div>
                 </div>
             </div>
             <div className="absolute bottom-4 w-40 h-20 bg-black/40 rounded-t-xl border-x-4 border-t-4 border-black/20 flex items-end justify-center overflow-visible">
                {phase !== 'IDLE' && phase !== 'SHUFFLING' && (
                    <div className={`w-20 h-20 rounded-full bg-gradient-to-br from-gold-400 to-gold-500 border-4 border-white shadow-2xl absolute bottom-2 z-40 ${phase === 'DROPPING' ? 'animate-roll-down' : ''} ${phase === 'OPENING' ? 'animate-implode-explode' : ''} ${phase === 'REVEAL' ? 'opacity-0' : ''}`}></div>
                )}
             </div>
        </div>
      </div>
    </div>
  );
};

// --- View Components ---

const Navbar: React.FC<{ userRole: UserRole; userTier: SubscriptionTier }> = ({ userRole, userTier }) => (
  <nav className="bg-white border-b border-gray-100 sticky top-0 z-40">
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex justify-between h-16">
        <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center cursor-pointer">
            <span className="text-xl font-bold text-slate-900 tracking-tighter">WeDraw.</span>
            </Link>
            <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
                <Link to="/pricing" className="hover:text-black transition">訂閱方案</Link>
                <Link to="/tutorial" className="hover:text-black transition">使用教學</Link>
            </div>
        </div>
        <div className="flex items-center space-x-6">
          {userRole === UserRole.GUEST ? (
            <>
              <Link to="/login" className="text-sm font-medium bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition">登入 / 註冊</Link>
            </>
          ) : (
            <>
              <Link to="/settings" className={`flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-full transition ${userRole === UserRole.FREE_USER ? 'bg-gray-100 text-gray-500 hover:bg-gray-200' : 'bg-amber-100 text-amber-700 hover:bg-amber-200'}`}>
                {userRole === UserRole.ADMIN ? 'ADMIN' : (userRole === UserRole.PAID_USER ? userTier : 'FREE')}
              </Link>
              {userRole === UserRole.ADMIN && (
                  <Link to="/admin" className="text-sm font-medium text-gray-900 hover:text-indigo-600">後台管理</Link>
              )}
              {userRole !== UserRole.ADMIN && (
                <Link to="/dashboard" className="text-sm font-medium text-gray-900">活動 Dashboard</Link>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  </nav>
);

const HomeView: React.FC = () => (
  <div className="bg-white min-h-screen font-sans text-slate-900">
    <Helmet>
        <title>WeDraw | 免費線上抽獎神器 - 支援名字跳跳、扭蛋機</title>
        <meta name="description" content="WeDraw 是香港 No.1 線上抽獎平台。無需下載 App，網頁即開即用。內建名字跳跳、3D 扭蛋機等抽獎模式，支援 Excel 匯入名單，適合公司年會、春茗、婚禮、活動使用。" />
        <meta name="keywords" content="抽獎, 抽獎神器, 線上抽獎, 名字跳跳, 扭蛋機, 公司年會, WeDraw, Lucky Draw Hong Kong" />
    </Helmet>
    <main className="max-w-4xl mx-auto px-4 pt-32 pb-16 text-center">
        <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-8 text-slate-900 animate-pop-in">Less is More.<br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-600 to-indigo-600">Just Draw.</span></h1>
        <p className="text-xl text-gray-500 max-w-xl mx-auto mb-12 leading-relaxed">WeDraw 專業抽獎平台。<br/>專注於活動氣氛，摒棄多餘操作。一鍵抽獎，流暢體驗。</p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/login" className="h-14 px-8 bg-black text-white text-lg font-medium rounded-lg hover:bg-gray-800 transition-all flex items-center justify-center gap-2">立即開始</Link>
            <Link to="/pricing" className="h-14 px-8 bg-white text-black border border-gray-200 text-lg font-medium rounded-lg hover:border-black transition-all flex items-center justify-center">訂閱方案</Link>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="p-6 bg-gray-50 rounded-2xl">
                <div className="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center mb-4"><Icons.Play className="w-5 h-5" /></div>
                <h3 className="font-bold text-lg mb-2">多種抽獎模式</h3>
                <p className="text-gray-500 text-sm">內建名字跳跳 (Jump) 與 3D 扭蛋機 (Gacha) 模式，滿足不同活動場景需求。</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-2xl">
                <div className="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center mb-4"><Icons.Users className="w-5 h-5" /></div>
                <h3 className="font-bold text-lg mb-2">Excel 一鍵匯入</h3>
                <p className="text-gray-500 text-sm">支援 Excel/CSV 檔案批次匯入名單，輕鬆管理萬人參與的大型活動。</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-2xl">
                <div className="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center mb-4"><Icons.Lock className="w-5 h-5 !w-6 !h-6" /></div>
                <h3 className="font-bold text-lg mb-2">安全可靠</h3>
                <p className="text-gray-500 text-sm">Firebase 雲端資料同步，PayPal 安全支付，確保活動順利進行。</p>
            </div>
        </div>
    </main>
  </div>
);

const TutorialView: React.FC = () => (
    <div className="max-w-4xl mx-auto px-4 py-16">
        <Helmet>
            <title>如何舉辦抽獎活動？WeDraw 完整教學</title>
            <meta name="description" content="5分鐘學會使用 WeDraw 舉辦專業抽獎活動。從建立活動、匯入 Excel 名單到設定抽獎輪次，完整圖文教學。" />
        </Helmet>
        <h1 className="text-4xl font-bold mb-8 text-center">使用教學</h1>
        <div className="space-y-12">
            <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-bold text-xl shrink-0">1</div>
                <div>
                    <h3 className="text-2xl font-bold mb-2">建立活動</h3>
                    <p className="text-gray-600 mb-4">註冊並登入後，在 Dashboard 點擊「+ 新活動」。輸入活動名稱（如：2025 公司年會）即可建立。</p>
                    <div className="bg-gray-100 p-4 rounded-lg border border-gray-200 text-sm text-gray-500">Tip: 不同訂閱等級有不同的活動數量上限。</div>
                </div>
            </div>
            <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-bold text-xl shrink-0">2</div>
                <div>
                    <h3 className="text-2xl font-bold mb-2">匯入名單</h3>
                    <p className="text-gray-600 mb-4">進入活動詳情頁，點擊「匯入名單」。您可以直接貼上名字（每行一個），或使用 Excel (.xlsx) 檔案匯入。</p>
                    <ul className="list-disc list-inside text-gray-600 ml-2">
                        <li>Excel 格式：請將名字放在第一欄 (Column A)。</li>
                        <li>支援格式：.xlsx, .csv</li>
                    </ul>
                </div>
            </div>
            <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-bold text-xl shrink-0">3</div>
                <div>
                    <h3 className="text-2xl font-bold mb-2">設定抽獎輪次</h3>
                    <p className="text-gray-600 mb-4">點擊「+ 新增輪次」來設定獎項。您可以設定：</p>
                    <ul className="list-disc list-inside text-gray-600 ml-2 mb-4">
                        <li>抽獎模式（名字跳跳 或 扭蛋機）</li>
                        <li>獎品名稱與圖片</li>
                        <li>一次抽出的人數</li>
                    </ul>
                </div>
            </div>
             <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-bold text-xl shrink-0">4</div>
                <div>
                    <h3 className="text-2xl font-bold mb-2">開始抽獎！</h3>
                    <p className="text-gray-600">一切準備就緒，點擊「進入抽獎模式」。建議使用全螢幕或投影機投射到大螢幕上，享受刺激的抽獎過程。</p>
                </div>
            </div>
        </div>
    </div>
);

const SettingsView: React.FC<{ user: User; onLogout: () => void }> = ({ user, onLogout }) => {
    return (
        <div className="max-w-2xl mx-auto px-4 py-12">
            <Helmet><title>帳戶設定 | WeDraw</title></Helmet>
            <h1 className="text-3xl font-bold text-slate-900 mb-8">帳戶設定</h1>
            <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm mb-8">
                <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-2xl font-bold text-gray-400">{user.email[0].toUpperCase()}</div>
                    <div>
                        <div className="font-bold text-xl text-gray-900">{user.email}</div>
                        <div className="text-sm text-gray-500">Joined on {new Date(user.joinedAt).toLocaleDateString()}</div>
                    </div>
                </div>
                <div className="border-t border-gray-100 pt-6 grid gap-4">
                    <div className="flex justify-between items-center">
                        <span className="text-gray-600 font-medium">會員等級</span>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${user.role === UserRole.FREE_USER ? 'bg-gray-100 text-gray-500' : 'bg-amber-100 text-amber-700'}`}>{user.tier}</span>
                    </div>
                    {user.role === UserRole.PAID_USER && (
                        <div className="flex justify-between items-center">
                            <span className="text-gray-600 font-medium">訂閱狀態</span>
                            <span className="text-green-600 font-bold flex items-center gap-1"><Icons.Check className="w-4 h-4" /> Active</span>
                        </div>
                    )}
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg text-sm text-gray-500">
                        如需取消訂閱或變更付款方式，請前往 <a href="https://www.paypal.com/myaccount/autopay/" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">PayPal 帳戶設定</a>。
                    </div>
                </div>
            </div>
            <button onClick={onLogout} className="w-full py-4 border border-gray-200 rounded-xl font-bold text-red-500 hover:bg-red-50 transition flex items-center justify-center gap-2"><Icons.Logout /> 登出帳號</button>
        </div>
    );
};

const LoginView: React.FC<{ initialMode?: 'login' | 'register' }> = ({ initialMode = 'login' }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const from = queryParams.get('from') || '/dashboard';

  const [isRegistering, setIsRegistering] = useState(initialMode === 'register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [resetSent, setResetSent] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
        if (isRegistering) {
            await createUserWithEmailAndPassword(auth, email, password);
            // TODO: Trigger Email Extension here
        } else {
            await signInWithEmailAndPassword(auth, email, password);
        }
        navigate(from);
    } catch (err: any) {
        setError(err.message);
    }
  };

  const handleGoogleLogin = async () => {
      try {
          await signInWithPopup(auth, googleProvider);
          // TODO: Trigger Email Extension here if new user
          navigate(from);
      } catch (err: any) {
          setError(err.message);
      }
  };

  const handleForgotPassword = async () => {
      if (!email) { setError('請先輸入 Email'); return; }
      try {
          await sendPasswordResetEmail(auth, email);
          setResetSent(true);
          setError('');
      } catch (err: any) {
          setError(err.message);
      }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 min-h-[80vh]">
      <Helmet>
        <title>{isRegistering ? '註冊帳號 | WeDraw' : '會員登入 | WeDraw'}</title>
      </Helmet>
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-xl border border-gray-100 text-center animate-pop-in">
          <h2 className="text-3xl font-bold text-slate-900 mb-2">{isRegistering ? '建立 WeDraw 帳戶' : '會員登入'}</h2>
          <button onClick={handleGoogleLogin} className="w-full py-3 border border-gray-200 rounded-lg flex items-center justify-center gap-3 font-bold text-gray-700 hover:bg-gray-50 transition mb-6 mt-6"><div className="w-5 h-5"><Icons.Google /></div> Continue with Google</button>
          <div className="relative mb-6"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200"></div></div><div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-gray-500">或使用 Email</span></div></div>
          <form onSubmit={handleAuth} className="space-y-4">
              <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg outline-none focus:border-black transition" required />
              {!resetSent && <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg outline-none focus:border-black transition" required /> }
              {error && <p className={`text-sm ${error.includes('sent') ? 'text-green-600' : 'text-red-500'}`}>{error}</p>}
              {resetSent && <p className="text-green-600 text-sm bg-green-50 p-2 rounded">重設密碼信件已發送，請檢查 Email。</p>}
              
              {!resetSent ? (
                  <button type="submit" className="w-full bg-black text-white font-bold py-3 rounded-lg hover:bg-gray-800 transition shadow-lg">{isRegistering ? '註冊' : '登入'}</button>
              ) : (
                  <button type="button" onClick={() => setResetSent(false)} className="w-full bg-black text-white font-bold py-3 rounded-lg hover:bg-gray-800">返回登入</button>
              )}
          </form>
          
          {!isRegistering && !resetSent && (
              <button onClick={handleForgotPassword} className="text-xs text-gray-400 mt-2 hover:text-black">忘記密碼？</button>
          )}

          <div className="mt-6 text-sm text-gray-600">{isRegistering ? '已經有帳號？' : '還沒有帳號？'} <button onClick={() => { setIsRegistering(!isRegistering); setResetSent(false); setError(''); }} className="font-bold text-black hover:underline">{isRegistering ? '登入' : '立即註冊'}</button></div>
      </div>
    </div>
  );
};

const AdminLoginView: React.FC = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleAdminLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await signInWithEmailAndPassword(auth, email.trim(), password.trim());
            navigate('/admin');
        } catch (err: any) {
            setError("Access Denied: Invalid Credentials or Insufficient Privileges");
        }
    };

    return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
            <Helmet><title>Admin Console | WeDraw System</title></Helmet>
            <div className="w-full max-w-md bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-2xl">
                <h2 className="text-2xl font-bold text-white mb-6">WeDraw System Admin</h2>
                <form onSubmit={handleAdminLogin} className="space-y-4">
                    <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 bg-slate-900 border border-slate-700 rounded-lg text-white" placeholder="Admin Email" />
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 bg-slate-900 border border-slate-700 rounded-lg text-white" placeholder="Password" />
                    {error && <p className="text-red-500">{error}</p>}
                    <button type="submit" className="w-full bg-red-600 text-white font-bold py-3 rounded-lg">Access Console</button>
                </form>
            </div>
        </div>
    );
};

const CheckoutView: React.FC<{ user: User | null; onSubscribe: (tier: SubscriptionTier, planId: string, orderId: string) => void }> = ({ user, onSubscribe }) => {
    const { tier } = useParams();
    const navigate = useNavigate();
    const selectedTier = (tier as SubscriptionTier) || SubscriptionTier.STARTER;
    
    let price = 198;
    let planId = PLAN_IDS.STARTER;
    if (selectedTier === SubscriptionTier.BUSINESS) { price = 398; planId = PLAN_IDS.BUSINESS; }
    if (selectedTier === SubscriptionTier.ENTERPRISE) { price = 798; planId = PLAN_IDS.ENTERPRISE; }

    const isTrial = selectedTier === SubscriptionTier.STARTER;
    const [isRegistering, setIsRegistering] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleInlineAuth = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        try {
            if (isRegistering) {
                 await createUserWithEmailAndPassword(auth, email, password);
                 // TODO: Trigger Email Notification
            }
            else await signInWithEmailAndPassword(auth, email, password);
        } catch (err: any) { setError(err.message); }
    };
    
    const handleGoogle = async () => {
         try {
            await signInWithPopup(auth, googleProvider);
         } catch (err: any) { setError(err.message); }
    };

    return (
        <div className="min-h-screen bg-gray-50 py-12 px-4">
            <Helmet><title>Secure Checkout | WeDraw</title></Helmet>
            <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200 h-fit">
                    <h2 className="text-2xl font-bold text-slate-900 mb-6">訂閱概要</h2>
                    <div className="flex justify-between items-start mb-6 pb-6 border-b border-gray-100">
                        <div>
                            <div className="text-sm text-gray-500 uppercase font-bold tracking-wider mb-1">WeDraw Plan</div>
                            <div className="text-3xl font-bold text-slate-900">{selectedTier}</div>
                        </div>
                        <div className="text-right">
                            <div className="text-2xl font-bold">HK${price}</div>
                            <div className="text-sm text-gray-500">/ month</div>
                        </div>
                    </div>
                    <div className="space-y-4 mb-6">
                        {isTrial ? (
                            <div className="flex items-center gap-3 bg-green-50 p-3 rounded-lg text-green-700 font-bold text-sm">
                                <Icons.Gift className="w-5 h-5" />
                                <span>包含 1 天免費試用 (1-Day Free Trial)</span>
                            </div>
                        ) : (
                            <div className="flex items-center gap-3 bg-gray-50 p-3 rounded-lg text-gray-600 font-medium text-sm">
                                <Icons.CreditCard className="w-5 h-5" />
                                <span>立即扣款，每月自動續費</span>
                            </div>
                        )}
                    </div>
                    <ul className="space-y-2 text-sm text-gray-600">
                        <li>• 解鎖完整後台功能</li>
                        <li>• {TIER_LIMITS[selectedTier].activities} 個活動上限</li>
                        <li>• {TIER_LIMITS[selectedTier].participants} 人參與上限</li>
                    </ul>
                </div>
                <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200 relative overflow-hidden">
                    {user ? (
                        <div className="animate-fade-in">
                            <div className="flex items-center gap-3 mb-6 p-4 bg-gray-50 rounded-xl">
                                <div className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center font-bold">{user.email[0].toUpperCase()}</div>
                                <div className="overflow-hidden">
                                    <div className="text-xs text-gray-500 font-bold uppercase">Paying as</div>
                                    <div className="text-sm font-bold truncate">{user.email}</div>
                                </div>
                            </div>
                            <h3 className="text-lg font-bold mb-4">選擇付款方式</h3>
                            <PayPalScriptProvider options={{ clientId: PAYPAL_CLIENT_ID, components: "buttons", currency: "HKD", intent: "subscription", vault: true }}>
                                <PayPalButtons 
                                    style={{ shape: 'rect', color: 'black', layout: 'vertical', label: 'pay' }}
                                    createSubscription={(data, actions) => actions.subscription.create({ 'plan_id': planId })}
                                    onApprove={async (data) => { await onSubscribe(selectedTier, planId, data.orderID || 'unknown'); navigate('/dashboard'); }}
                                />
                            </PayPalScriptProvider>
                        </div>
                    ) : (
                        <div className="animate-fade-in">
                             <h3 className="text-xl font-bold mb-6">{isRegistering ? '建立帳戶以付款' : '登入以付款'}</h3>
                             <button onClick={handleGoogle} className="w-full py-3 border border-gray-200 rounded-lg flex items-center justify-center gap-3 font-bold text-gray-700 hover:bg-gray-50 transition mb-6"><div className="w-5 h-5"><Icons.Google /></div> Continue with Google</button>
                             <div className="relative mb-6"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200"></div></div><div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-gray-500">或使用 Email</span></div></div>
                             <form onSubmit={handleInlineAuth} className="space-y-4">
                                <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg outline-none focus:border-black transition" required />
                                <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg outline-none focus:border-black transition" required />
                                {error && <p className="text-red-500 text-sm">{error}</p>}
                                <button type="submit" className="w-full bg-black text-white font-bold py-3 rounded-lg hover:bg-gray-800 transition">{isRegistering ? '註冊並繼續' : '登入並繼續'}</button>
                             </form>
                             <div className="mt-4 text-sm text-center text-gray-500">
                                 {isRegistering ? '已有帳號？' : '新用戶？'} <button onClick={() => setIsRegistering(!isRegistering)} className="font-bold text-black hover:underline">{isRegistering ? '登入' : '註冊'}</button>
                             </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const PricingCard: React.FC<{ 
    tier: string; 
    price: string; 
    features: string[]; 
    isPopular?: boolean;
    buttonText?: string;
    onClick?: () => void;
}> = ({ tier, price, features, isPopular, buttonText = "立即訂閱", onClick }) => {
    return (
        <div className={`bg-white rounded-2xl p-6 flex flex-col relative border transition-all duration-300 ${isPopular ? 'border-black shadow-2xl scale-105 z-10' : 'border-gray-200 shadow-sm hover:shadow-md'}`}>
            {isPopular && <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-indigo-500 to-purple-600"></div>}
            {tier === 'Starter' && <div className="absolute top-4 right-4 bg-green-100 text-green-700 text-[10px] font-bold px-2 py-1 rounded-full">1-DAY FREE TRIAL</div>}
            
            <div className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">{tier}</div>
            <div className="text-4xl font-bold text-slate-900 mb-1">{price}</div>
            <div className="text-xs text-gray-400 mb-6">每月自動續費</div>
            
            <ul className="space-y-3 mb-8 flex-1">
                {features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                        <Icons.Check className={`w-4 h-4 mt-0.5 shrink-0 ${isPopular ? 'text-indigo-600' : 'text-green-500'}`}/> 
                        <span className="leading-tight">{f}</span>
                    </li>
                ))}
            </ul>
            
            <button onClick={onClick} className={`w-full py-3 font-bold rounded-lg transition ${isPopular ? 'bg-black text-white hover:bg-gray-800' : 'bg-white text-black border border-black hover:bg-gray-50'}`}>
                {buttonText}
            </button>
        </div>
    );
};

const PricingView: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="bg-white min-h-screen py-20 px-4">
      <Helmet>
        <title>WeDraw 訂閱方案 - 最低 $0 起</title>
        <meta name="description" content="選擇適合您的 WeDraw 方案。免費會員即可體驗，付費方案支援更多活動與人數，並包含名字跳跳與扭蛋機模式。" />
      </Helmet>
      <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">選擇您的 WeDraw 方案</h2>
          <p className="text-gray-500 mb-12">彈性方案，隨時取消。所有付費方案均包含完整後台功能。</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-start">
                <PricingCard 
                    tier="Free Member" 
                    price="HK$0"
                    buttonText="註冊帳號"
                    onClick={() => navigate('/login?initialMode=register')}
                    features={['僅限註冊帳號', '瀏覽介面', '無法建立活動', '無法進行抽獎']} 
                />
                <PricingCard 
                    tier="Starter" 
                    price="HK$198"
                    isPopular={true}
                    onClick={() => navigate(`/checkout/${SubscriptionTier.STARTER}`)}
                    features={[
                        '1 天免費試用 (Free Trial)',
                        `${TIER_LIMITS.STARTER.activities} 個活動上限`, 
                        `${TIER_LIMITS.STARTER.rounds} 個抽獎輪次/活動`, 
                        `上限 ${TIER_LIMITS.STARTER.participants} 人`,
                        '標準抽獎模式'
                    ]} 
                />
                <PricingCard 
                    tier="Business" 
                    price="HK$398"
                    onClick={() => navigate(`/checkout/${SubscriptionTier.BUSINESS}`)}
                    features={[
                        `${TIER_LIMITS.BUSINESS.activities} 個活動上限`, 
                        `${TIER_LIMITS.BUSINESS.rounds} 個抽獎輪次/活動`, 
                        `上限 ${TIER_LIMITS.BUSINESS.participants} 人`,
                        '優先客服支援'
                    ]} 
                />
                <PricingCard 
                    tier="Enterprise" 
                    price="HK$798"
                    onClick={() => navigate(`/checkout/${SubscriptionTier.ENTERPRISE}`)}
                    features={[
                        `${TIER_LIMITS.ENTERPRISE.activities} 個活動上限`, 
                        `${TIER_LIMITS.ENTERPRISE.rounds} 個抽獎輪次/活動`, 
                        `上限 ${TIER_LIMITS.ENTERPRISE.participants} 人`, 
                        "內定得獎者功能 (Rigging)",
                        "專屬伺服器資源"
                    ]} 
                />
          </div>
      </div>
    </div>
  );
};

const AdminView: React.FC = () => {
  const [tab, setTab] = useState<'USERS' | 'PAYMENTS'>('USERS');
  const [users, setUsers] = useState<User[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', tier: SubscriptionTier.STARTER });

  useEffect(() => {
      const load = async () => {
          setUsers(await dbService.getUsers());
          setPayments(await dbService.getPayments());
      };
      load();
  }, [tab]);

  const handleAddUser = async () => {
      if (!newUser.email) return;
      const id = 'manual-' + Date.now();
      const u: User = { 
          id, email: newUser.email, role: UserRole.PAID_USER, tier: newUser.tier, joinedAt: new Date().toISOString() 
      };
      await dbService.createUser(u);
      setUsers([...users, u]);
      setShowAddUser(false);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 min-h-screen bg-gray-50">
        <Helmet><title>WeDraw Admin Console</title></Helmet>
        <h1 className="text-3xl font-bold mb-8 text-slate-900">WeDraw Admin Console</h1>
        <div className="flex gap-4 mb-6">
            <button onClick={() => setTab('USERS')} className={`px-4 py-2 rounded font-bold ${tab === 'USERS' ? 'bg-black text-white' : 'bg-white text-gray-600'}`}>Users</button>
            <button onClick={() => setTab('PAYMENTS')} className={`px-4 py-2 rounded font-bold ${tab === 'PAYMENTS' ? 'bg-black text-white' : 'bg-white text-gray-600'}`}>Payments</button>
        </div>
        
        {tab === 'USERS' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex justify-between mb-4"><h3 className="font-bold">User Management</h3><button onClick={() => setShowAddUser(true)} className="text-sm bg-indigo-600 text-white px-3 py-1 rounded font-bold">+ Add User</button></div>
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50"><tr><th className="p-3">Email</th><th className="p-3">Role</th><th className="p-3">Tier</th><th className="p-3">Actions</th></tr></thead>
                    <tbody>
                        {users.map(u => (
                            <tr key={u.id} className="border-b border-gray-100">
                                <td className="p-3">{u.email}</td>
                                <td className="p-3">{u.role}</td>
                                <td className="p-3">
                                    <select value={u.tier} onChange={async (e) => {
                                        const t = e.target.value as SubscriptionTier;
                                        await dbService.updateUser(u.id, { tier: t, role: t === SubscriptionTier.FREE ? UserRole.FREE_USER : UserRole.PAID_USER });
                                        setUsers(users.map(x => x.id === u.id ? {...x, tier: t, role: t === SubscriptionTier.FREE ? UserRole.FREE_USER : UserRole.PAID_USER} : x));
                                    }} className="bg-gray-50 border border-gray-200 rounded px-2 py-1">
                                        {Object.values(SubscriptionTier).map(t => <option key={t} value={t}>{t}</option>)}
                                    </select>
                                </td>
                                <td className="p-3"><button onClick={async () => { if(confirm('Delete?')) { await dbService.deleteUser(u.id); setUsers(users.filter(x => x.id !== u.id)); }}} className="text-red-500">Delete</button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
        {/* Payments Tab Omitted for brevity - unchanged */}
        <Modal isOpen={showAddUser} onClose={() => setShowAddUser(false)} title="Manually Add User">
             <input className="w-full border p-2 rounded mb-4" placeholder="Email" value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} />
             <select className="w-full border p-2 rounded mb-4" value={newUser.tier} onChange={e => setNewUser({...newUser, tier: e.target.value as SubscriptionTier})}>
                 {Object.values(SubscriptionTier).map(t => <option key={t} value={t}>{t}</option>)}
             </select>
             <button onClick={handleAddUser} className="w-full bg-black text-white py-2 rounded font-bold">Create</button>
        </Modal>
    </div>
  );
};

const DashboardView: React.FC<{ activities: Activity[]; setActivities: (a: Activity[]) => void; activeActivity: Activity | null; setActiveActivity: (a: Activity | null) => void; user: User; }> = ({ activities, setActivities, activeActivity, setActiveActivity, user }) => {
  const navigate = useNavigate();
  const [showWizard, setShowWizard] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importText, setImportText] = useState('');
  const [showRoundModal, setShowRoundModal] = useState(false);
  const [editingRound, setEditingRound] = useState<Partial<Round>>({});
  const [fileError, setFileError] = useState('');

  if (user.role === UserRole.FREE_USER) {
      return (
          <div className="max-w-4xl mx-auto px-4 py-20 text-center">
              <Helmet><title>Dashboard | WeDraw</title></Helmet>
              <div className="bg-white border border-gray-200 rounded-2xl p-12 shadow-2xl relative overflow-hidden">
                  <div className="absolute inset-0 bg-gray-100/50 backdrop-blur-[2px]"></div>
                  <div className="relative z-10 flex flex-col items-center">
                      <div className="w-20 h-20 bg-black text-white rounded-full flex items-center justify-center mb-6"><Icons.Lock /></div>
                      <h2 className="text-3xl font-bold mb-4">訂閱以解鎖 Dashboard</h2>
                      <Link to="/pricing" className="px-8 py-4 bg-black text-white font-bold rounded-xl hover:bg-gray-800 transition shadow-lg hover:scale-105 transform">查看方案</Link>
                  </div>
              </div>
          </div>
      );
  }

  const limits = TIER_LIMITS[user.tier] || TIER_LIMITS.FREE;

  const checkLimit = (type: 'activity' | 'round' | 'participant', currentCount: number) => {
      let limit = 0;
      if (type === 'activity') limit = limits.activities;
      if (type === 'round') limit = limits.rounds;
      if (type === 'participant') limit = limits.participants;
      
      if (currentCount >= limit) {
          alert(`已達到您的 ${user.tier} 方案上限 (${limit})。請升級方案以建立更多。`);
          return false;
      }
      return true;
  };

  const handleCreateActivity = async (name: string) => {
    if (!checkLimit('activity', activities.length)) return;
    const newActivity: Activity = { id: Date.now().toString(), name, date: new Date().toISOString(), participants: [], rounds: [], userId: user.id };
    await dbService.saveActivity(newActivity, user.id);
    setActivities([newActivity, ...activities]);
    setActiveActivity(newActivity);
    setShowWizard(false);
  };

  const handleImportText = async () => {
      if (!activeActivity) return;
      const names = importText.split(/[\n,]+/).map(n => n.trim()).filter(n => n.length > 0);
      if (names.length === 0) return;
      if (!checkLimit('participant', activeActivity.participants.length + names.length)) return;

      const newPart = names.map(n => ({ id: Math.random().toString(36).substr(2, 9), name: n }));
      const updated = { ...activeActivity, participants: [...activeActivity.participants, ...newPart] };
      await dbService.saveActivity(updated, user.id);
      setActiveActivity(updated);
      setActivities(activities.map(a => a.id === updated.id ? updated : a));
      setImportText('');
      setShowImportModal(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (!activeActivity) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
          const bstr = evt.target?.result;
          const wb = XLSX.read(bstr, { type: 'binary' });
          const wsname = wb.SheetNames[0];
          const ws = wb.Sheets[wsname];
          const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
          
          // Assume first column is names
          const names: string[] = data.map(row => row[0]).filter(n => n && typeof n === 'string' && n.trim().length > 0);
          
          if (!checkLimit('participant', activeActivity.participants.length + names.length)) return;

          const newPart = names.map(n => ({ id: Math.random().toString(36).substr(2, 9), name: n }));
          const updated = { ...activeActivity, participants: [...activeActivity.participants, ...newPart] };
          dbService.saveActivity(updated, user.id).then(() => {
             setActiveActivity(updated);
             setActivities(activities.map(a => a.id === updated.id ? updated : a));
             setShowImportModal(false);
          });
      };
      reader.readAsBinaryString(file);
  };

  const openNewRoundModal = () => {
      setEditingRound({}); // Reset state completely for new round
      setFileError('');
      setShowRoundModal(true);
  }

  const handleSaveRound = async () => {
      if (!activeActivity) return;
      // If new round (no ID yet), check limit
      if (!editingRound.id && !checkLimit('round', activeActivity.rounds.length)) return;

      const newRound: Round = {
          id: editingRound.id || Date.now().toString(),
          name: editingRound.name || '新抽獎輪次',
          mode: editingRound.mode || DrawMode.JUMP,
          prizeName: editingRound.prizeName || '神秘獎品',
          prizeImage: editingRound.prizeImage,
          winnerCount: editingRound.winnerCount || 1,
          removeWinner: true,
          winners: editingRound.winners || [],
          isCompleted: false,
          riggedWinnerId: editingRound.riggedWinnerId
      };

      let newRounds;
      if (editingRound.id) {
           newRounds = activeActivity.rounds.map(r => r.id === newRound.id ? newRound : r);
      } else {
           newRounds = [...activeActivity.rounds, newRound];
      }
      
      const updated = { ...activeActivity, rounds: newRounds };
      await dbService.saveActivity(updated, user.id);
      setActiveActivity(updated);
      setActivities(activities.map(a => a.id === updated.id ? updated : a));
      setShowRoundModal(false);
      setEditingRound({});
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setFileError('');
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
          setFileError('圖片大小不能超過 2MB');
          return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setEditingRound(prev => ({ ...prev, prizeImage: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="pb-20">
      <Helmet><title>Dashboard | WeDraw</title></Helmet>
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="flex justify-between items-end mb-8">
             <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Dashboard ({user.tier})</h1>
             <button onClick={() => setShowWizard(true)} className="bg-black text-white px-5 py-2 rounded-lg font-medium hover:bg-gray-800 transition flex items-center gap-2"><Icons.Plus /> 新活動</button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
             <div className="lg:col-span-4 space-y-2">
                {activities.map(act => (
                    <div key={act.id} onClick={() => setActiveActivity(act)} className={`p-4 rounded-xl cursor-pointer transition-all border flex justify-between items-center group ${activeActivity?.id === act.id ? 'bg-black text-white border-black shadow-lg' : 'bg-white border-gray-200 hover:border-gray-300 text-gray-900'}`}>
                       <div><h4 className="font-bold">{act.name}</h4></div>
                    </div>
                ))}
             </div>
             <div className="lg:col-span-8">
                {activeActivity ? (
                  <div className="space-y-6 animate-[fade-in_0.2s]">
                     <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-6 border-b border-gray-100 gap-4">
                        <div><h2 className="text-2xl font-bold">{activeActivity.name}</h2><div className="text-sm text-gray-500 mt-1">參與人數: {activeActivity.participants.length} · 輪次: {activeActivity.rounds.length}</div></div>
                        {activeActivity.rounds.length > 0 && (
                            <button onClick={() => navigate(`/activity/${activeActivity.id}/draw`)} className="bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg hover:scale-105 transition-all flex items-center gap-2"><Icons.Play className="w-5 h-5" /> 進入抽獎模式</button>
                        )}
                     </div>
                     <div>
                        <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-lg">輪次管理</h3><button onClick={openNewRoundModal} className="text-sm font-bold text-indigo-600 hover:text-indigo-800">+ 新增輪次</button></div>
                        <div className="space-y-3">
                        {activeActivity.rounds.map((round) => (
                            <div key={round.id} className="flex items-center justify-between p-5 border border-gray-200 rounded-xl bg-gray-50 hover:bg-white transition group">
                                <div className="flex items-center gap-4">
                                    {round.prizeImage && <img src={round.prizeImage} className="w-12 h-12 rounded-lg object-cover border border-gray-100" />}
                                    <div className="flex items-center gap-3 mb-1"><h4 className="font-bold text-lg">{round.prizeName}</h4></div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => { setEditingRound(round); setShowRoundModal(true); }} className="p-2 text-gray-400 hover:text-black bg-white border border-gray-200 rounded-lg"><Icons.Edit /></button>
                                </div>
                            </div>
                        ))}
                        </div>
                     </div>
                     <div>
                        <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-lg">名單管理</h3><button onClick={() => setShowImportModal(true)} className="text-sm font-bold text-indigo-600 hover:text-indigo-800">匯入名單</button></div>
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 min-h-[100px] flex flex-wrap gap-2">
                            {activeActivity.participants.slice(0, 50).map(p => (<span key={p.id} className="bg-white border border-gray-200 px-2 py-1 rounded text-xs text-gray-600">{p.name}</span>))}
                        </div>
                     </div>
                  </div>
                ) : <div className="h-96 flex items-center justify-center text-gray-300">請選擇或建立活動</div>}
             </div>
        </div>
        
        <ActivityWizard isOpen={showWizard} onClose={() => setShowWizard(false)} onComplete={handleCreateActivity} />
        
        <Modal isOpen={showImportModal} onClose={() => setShowImportModal(false)} title="匯入名單">
             <div className="space-y-4">
                 <div className="border-b border-gray-100 pb-4 mb-4">
                    <label className="block text-sm font-bold mb-2">方法 1: 上傳 Excel / CSV</label>
                    <input type="file" accept=".xlsx, .xls, .csv" onChange={handleFileUpload} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-violet-50 file:text-violet-700 hover:file:bg-violet-100" />
                    <p className="text-xs text-gray-400 mt-1">請確保名字在第一欄 (Column A)</p>
                 </div>
                 <div>
                    <label className="block text-sm font-bold mb-2">方法 2: 手動貼上</label>
                    <textarea className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg p-3 font-mono text-sm outline-none focus:border-black transition" placeholder={"阿明\n小紅"} value={importText} onChange={e => setImportText(e.target.value)} />
                    <button onClick={handleImportText} className="w-full bg-black text-white font-medium py-3 rounded-lg hover:bg-gray-800 mt-2">匯入文字</button>
                 </div>
             </div>
        </Modal>
        
        <Modal isOpen={showRoundModal} onClose={() => setShowRoundModal(false)} title={editingRound.id ? "編輯輪次" : "新增輪次"}>
            <div className="space-y-4">
               <input className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2" value={editingRound.name || ''} placeholder="輪次名稱 (如: 三等獎)" onChange={e => setEditingRound({...editingRound, name: e.target.value})} />
               <input className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2" value={editingRound.prizeName || ''} placeholder="獎品名稱 (如: Dyson 風筒)" onChange={e => setEditingRound({...editingRound, prizeName: e.target.value})} />
               
               <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                    <label className="block cursor-pointer text-sm text-gray-600 mb-2"><Icons.Image /> 獎品圖片 (Max 2MB)</label>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="text-sm text-gray-500" />
                    {fileError && <p className="text-red-500 text-xs mt-1">{fileError}</p>}
                    {editingRound.prizeImage && (
                        <img src={editingRound.prizeImage} alt="Preview" className="mt-2 h-20 w-20 object-cover rounded-lg border border-gray-300" />
                    )}
               </div>

               <div className="grid grid-cols-2 gap-4">
                  <select className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2" value={editingRound.mode || DrawMode.JUMP} onChange={e => setEditingRound({...editingRound, mode: e.target.value as DrawMode})}><option value={DrawMode.JUMP}>名字跳跳</option><option value={DrawMode.GACHA}>扭蛋機</option></select>
                  <input type="number" placeholder="中獎人數" className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2" value={editingRound.winnerCount || 1} onChange={e => setEditingRound({...editingRound, winnerCount: parseInt(e.target.value)})} />
               </div>
               
               {user.tier === SubscriptionTier.ENTERPRISE && (
                   <div className="border-t border-gray-100 pt-4 mt-4">
                       <label className="block text-xs font-bold text-purple-600 mb-1">內定得獎者 (Enterprise Exclusive)</label>
                       <select className="w-full bg-purple-50 border border-purple-100 rounded-lg p-2 text-sm" value={editingRound.riggedWinnerId || ''} onChange={e => setEditingRound({...editingRound, riggedWinnerId: e.target.value})}>
                           <option value="">-- 隨機 (無內定) --</option>
                           {activeActivity?.participants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                       </select>
                   </div>
               )}

               <button onClick={handleSaveRound} className="w-full bg-black text-white font-medium py-3 rounded-lg hover:bg-gray-800">儲存</button>
            </div>
        </Modal>
      </div>
    </div>
  );
};

const DrawScreen: React.FC<{ activities: Activity[]; setActivities: (a: Activity[]) => void }> = ({ activities, setActivities }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const activity = activities.find(a => a.id === id);
  
  const [currentRoundIndex, setCurrentRoundIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [generatedMessage, setGeneratedMessage] = useState('');
  const [targetWinners, setTargetWinners] = useState<Winner[] | null>(null);

  if (!activity) return <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">Loading Activity...</div>;
  
  // Handle case where activity exists but no rounds
  if (!activity.rounds || activity.rounds.length === 0) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center gap-4">
            <h2 className="text-2xl font-bold">尚未設定抽獎輪次</h2>
            <button onClick={() => navigate('/dashboard')} className="px-6 py-2 bg-white text-black rounded-full font-bold">返回 Dashboard</button>
        </div>
      );
  }

  const currentRound = activity.rounds[currentRoundIndex];

  const nextRound = () => { if (currentRoundIndex < activity.rounds.length - 1) { setCurrentRoundIndex(currentRoundIndex + 1); setTargetWinners(null); setShowCelebration(false); }};
  const prevRound = () => { if (currentRoundIndex > 0) { setCurrentRoundIndex(currentRoundIndex - 1); setTargetWinners(null); setShowCelebration(false); }};

  // Filter participants who haven't won yet (if removeWinner is true)
  // Logic: Check all rounds in this activity. If a participant is in winners list of a round that has removeWinner=true, exclude them.
  const availableParticipants = activity.participants.filter(p => {
      // Check if user has won in any completed round that removes winners
      const hasWon = activity.rounds.some(r => 
          r.isCompleted && r.removeWinner && r.winners.some(w => w.id === p.id)
      );
      return !hasWon;
  });

  const startDraw = async () => {
      if (currentRound.isCompleted && currentRound.winners.length > 0) {
          // Already drawn, just show winners
          setTargetWinners(currentRound.winners);
          setShowCelebration(true);
          return;
      }
      
      if (availableParticipants.length < currentRound.winnerCount) {
          alert(`參加者人數不足！剩餘 ${availableParticipants.length} 人，需抽出 ${currentRound.winnerCount} 人。`);
          return;
      }

      let winners: Participant[] = [];
      
      // 1. Handle Rigged Winner (Enterprise)
      if (currentRound.riggedWinnerId) {
          const riggedUser = availableParticipants.find(p => p.id === currentRound.riggedWinnerId);
          if (riggedUser) {
              winners.push(riggedUser);
          }
      }

      // 2. Random selection for remaining slots
      const remainingCount = currentRound.winnerCount - winners.length;
      if (remainingCount > 0) {
          // Exclude already picked rigged winner
          const pool = availableParticipants.filter(p => !winners.some(w => w.id === p.id));
          
          // Simple shuffle
          const shuffled = [...pool].sort(() => Math.random() - 0.5);
          winners = [...winners, ...shuffled.slice(0, remainingCount)];
      }

      const finalWinners: Winner[] = winners.map(w => ({
          ...w,
          wonAt: new Date().toISOString(),
          prizeName: currentRound.prizeName
      }));

      setTargetWinners(finalWinners);
      setIsRunning(true);
      setShowCelebration(false);
      setGeneratedMessage('');
  };

  const handleDrawComplete = async () => {
      setIsRunning(false);
      if (!targetWinners) return;
      
      // Save to DB
      const updatedRound: Round = { ...currentRound, winners: targetWinners, isCompleted: true };
      const updatedRounds = activity.rounds.map(r => r.id === currentRound.id ? updatedRound : r);
      const updatedActivity = { ...activity, rounds: updatedRounds };

      setActivities(activities.map(a => a.id === activity.id ? updatedActivity : a));
      await dbService.saveActivity(updatedActivity, activity.userId);

      setShowCelebration(true);

      // AI Hype Message
      try {
          const names = targetWinners.map(w => w.name).join(', ');
          const msg = await generateHypeMessage(names, currentRound.prizeName, activity.name);
          setGeneratedMessage(msg);
      } catch (e) {
          console.error(e);
      }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 overflow-hidden">
         <Helmet><title>{activity.name} - 抽獎進行中 | WeDraw</title></Helmet>
         {/* Top Bar */}
         <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start z-50">
             <div className="flex items-center gap-4">
                 <button onClick={() => setShowExitConfirm(true)} className="p-3 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-md text-white transition"><Icons.X /></button>
                 <div>
                     <h1 className="text-white font-bold text-xl drop-shadow-md">{activity.name}</h1>
                     <div className="flex items-center gap-2 text-indigo-200 text-sm font-bold">
                         <span className="px-2 py-0.5 bg-indigo-500/30 rounded border border-indigo-500/30">{currentRound.name}</span>
                         <span>{currentRound.prizeName}</span>
                     </div>
                 </div>
             </div>
             <div className="flex items-center gap-4 bg-black/30 backdrop-blur-md rounded-full p-1 border border-white/10">
                 <button onClick={prevRound} disabled={currentRoundIndex === 0} className="p-3 text-white hover:bg-white/20 rounded-full disabled:opacity-30 transition"><Icons.ChevronLeft /></button>
                 <span className="text-white font-mono font-bold w-12 text-center">{currentRoundIndex + 1} / {activity.rounds.length}</span>
                 <button onClick={nextRound} disabled={currentRoundIndex === activity.rounds.length - 1} className="p-3 text-white hover:bg-white/20 rounded-full disabled:opacity-30 transition"><Icons.ChevronRight /></button>
             </div>
         </div>

         {/* Main Area */}
         <div className="h-full w-full flex items-center justify-center">
             {currentRound.mode === DrawMode.GACHA ? (
                 <GachaEngine isRunning={isRunning} targetWinners={targetWinners} onComplete={handleDrawComplete} />
             ) : (
                 <JumpEngine participants={availableParticipants} isRunning={isRunning} targetWinners={targetWinners} onComplete={handleDrawComplete} />
             )}
         </div>

         {/* Start Button (Only if not running and not celebrating) */}
         {!isRunning && !showCelebration && (
             <div className="absolute bottom-12 left-0 right-0 flex justify-center z-40">
                 {currentRound.isCompleted ? (
                      <button onClick={() => setShowCelebration(true)} className="px-8 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-white font-bold hover:bg-white/20 transition flex items-center gap-2">
                          <Icons.Gift className="w-5 h-5" /> 查看得獎結果
                      </button>
                 ) : (
                      <button onClick={startDraw} className="group relative px-12 py-5 bg-white text-black rounded-full font-black text-2xl hover:scale-110 transition-all shadow-[0_0_50px_rgba(255,255,255,0.4)] overflow-hidden">
                          <span className="relative z-10">START DRAW</span>
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent w-1/2 skew-x-12 group-hover:animate-shimmer"></div>
                      </button>
                 )}
             </div>
         )}

         {/* Winner Modal / Celebration */}
         {showCelebration && targetWinners && (
             <div className="absolute inset-0 z-[60] bg-black/80 backdrop-blur-xl flex items-center justify-center p-4 animate-fade-in">
                 <div className="w-full max-w-4xl text-center">
                     <div className="mb-8">
                         <h2 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 to-yellow-600 drop-shadow-2xl mb-4 animate-pop-in">CONGRATS!</h2>
                         <p className="text-white/60 text-xl font-bold tracking-widest uppercase">{currentRound.prizeName} 得主</p>
                     </div>
                     
                     <div className="flex flex-wrap justify-center gap-6 mb-12">
                         {targetWinners.map((w, i) => (
                             <div key={i} className="bg-white text-slate-900 px-10 py-6 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] transform hover:scale-105 transition duration-300 animate-slide-up" style={{ animationDelay: `${i * 0.1}s` }}>
                                 <div className="text-4xl font-black tracking-tighter">{w.name}</div>
                             </div>
                         ))}
                     </div>
                     
                     {/* AI Message Area */}
                     <div className="max-w-2xl mx-auto mb-12 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                         <div className="flex items-center justify-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-widest mb-3">
                             <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div> AI MC Commentary
                         </div>
                         <p className="text-2xl font-medium text-white leading-relaxed">
                             {generatedMessage ? `"${generatedMessage}"` : <span className="animate-pulse text-white/50">正在連線 AI 主持人生成祝賀詞...</span>}
                         </p>
                     </div>

                     <div className="flex gap-4 justify-center">
                         <button onClick={() => setShowCelebration(false)} className="px-8 py-3 rounded-xl font-bold text-white border border-white/20 hover:bg-white/10 transition">關閉</button>
                         {currentRoundIndex < activity.rounds.length - 1 && (
                             <button onClick={nextRound} className="px-8 py-3 rounded-xl font-bold bg-white text-black hover:bg-gray-200 transition shadow-lg flex items-center gap-2">下一輪 <Icons.ChevronRight className="w-4 h-4" /></button>
                         )}
                     </div>
                 </div>
                 {/* Confetti effect could be added here if a library was available, but sticking to CSS/SVG */}
             </div>
         )}

         <ExitConfirmModal isOpen={showExitConfirm} onCancel={() => setShowExitConfirm(false)} onConfirm={() => navigate('/dashboard')} />
    </div>
  );
};

const App: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true); // Global Loading State
  const [user, setUser] = useState<User | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [activeActivity, setActiveActivity] = useState<Activity | null>(null);
  
  useEffect(() => {
    let unsubscribeUser: any = null;
    const unsubscribeAuth = onAuthStateChanged(auth, async (authUser) => {
        if (authUser) {
            unsubscribeUser = dbService.listenToUserProfile(authUser.uid, async (profile) => {
                let userData = profile;
                if (!userData) {
                    // New user
                    userData = { 
                        id: authUser.uid, 
                        email: authUser.email || '', 
                        role: UserRole.FREE_USER, 
                        tier: SubscriptionTier.FREE, 
                        joinedAt: new Date().toISOString() 
                    };
                }

                // Security: Auto-Promote specific admin email
                if (authUser.email === ADMIN_EMAIL) {
                    if (userData.role !== UserRole.ADMIN || userData.tier !== SubscriptionTier.ENTERPRISE) {
                        userData.role = UserRole.ADMIN;
                        userData.tier = SubscriptionTier.ENTERPRISE;
                        await dbService.saveUser(userData);
                    }
                }

                if (!profile) await dbService.saveUser(userData);

                setUser(userData);
                const userActivities = await dbService.getUserActivities(authUser.uid);
                setActivities(userActivities);
                setLoading(false); // Ready
            });
        } else {
            if (unsubscribeUser) unsubscribeUser();
            setUser(null);
            setActivities([]);
            setActiveActivity(null);
            setLoading(false); // Ready (Guest)
        }
    });
    return () => { unsubscribeAuth(); if (unsubscribeUser) unsubscribeUser(); };
  }, []);

  const handleSubscription = async (tier: SubscriptionTier, planId: string, orderId: string) => {
      if (!user) return;
      const updatedUser = { ...user, role: UserRole.PAID_USER, tier: tier };
      await dbService.saveUser(updatedUser);
      await dbService.recordPayment({
          id: orderId,
          userId: user.id,
          userEmail: user.email,
          amount: tier === SubscriptionTier.STARTER ? '198' : (tier === SubscriptionTier.BUSINESS ? '398' : '798'),
          currency: 'HKD',
          planId: planId,
          tier: tier,
          orderId: orderId,
          createdAt: new Date().toISOString()
      });
      // TODO: Trigger Email via Extension
  };

  if (loading) return <LoadingScreen />;

  return (
    <div className="font-sans text-slate-900 antialiased">
        {window.location.pathname !== '/lucky-admin' && (
            <Navbar userRole={user?.role || UserRole.GUEST} userTier={user?.tier || SubscriptionTier.FREE} />
        )}
        
        <Routes>
            <Route path="/" element={<HomeView />} />
            <Route path="/tutorial" element={<TutorialView />} />
            <Route path="/login" element={<LoginView />} />
            <Route path="/lucky-admin" element={<AdminLoginView />} />
            <Route path="/pricing" element={<PricingView />} />
            <Route path="/checkout/:tier" element={<CheckoutView user={user} onSubscribe={handleSubscription} />} />
            <Route path="/settings" element={!user ? <Navigate to="/login" /> : <SettingsView user={user} onLogout={() => { signOut(auth); setUser(null); navigate('/'); }} />} />
            <Route path="/dashboard" element={!user ? <Navigate to="/login" /> : <DashboardView activities={activities} setActivities={setActivities} activeActivity={activeActivity} setActiveActivity={setActiveActivity} user={user} />} />
            <Route path="/admin" element={user?.role === UserRole.ADMIN ? <AdminView /> : <Navigate to="/lucky-admin" />} />
            <Route path="/activity/:id/draw" element={<DrawScreen activities={activities} setActivities={setActivities} />} />
        </Routes>
    </div>
  );
};

export default App;